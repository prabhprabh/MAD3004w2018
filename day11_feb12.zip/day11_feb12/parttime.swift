//
//  parttime.swift
//  feb 12
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class partTime //student and fillti,e cant be extended as file private
{
    var sname : String?
    fileprivate func setstudentName(sname : String)
    {
        self.sname = sname
    }
}


internal class extendpartTime: partTime {
    override internal func setstudentName(sname: String)
    {
        super.setstudentName(sname: sname)
    }
}







