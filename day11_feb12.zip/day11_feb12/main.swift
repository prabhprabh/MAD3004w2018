//
//  main.swift
//  feb 12
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//var objStud = Student()
//objStud.display()

//var objFullTime = FullTime()
//objFullTime.display()


//Can be extended as Internal to the module
var p1 = partTime()

//Not possible as fileprivate
//p1.setStudentName("prabh")

class T: extendpartTime
{
    override init()
    {
        super.init()
        print("Display T")
    }
}

var t1 = T()


//Not possible as file private
//var s1 = Student()
//var f1 = FullTime()
