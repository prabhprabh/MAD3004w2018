//
//  student.swift
//  feb 12
//
//  Created by MacStudent on 2018-02-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


fileprivate class student
{
   private var sname :String?
    
    init()
    {
        self.sname = "student name"
        
    }
    func setStudentName(sname: String)
    {
        self.sname = sname
        
    }
    func getStudentName() -> String
    {
        return self.sname!
    }
   private func display(){
        print("im methopd of student class")
    }
   fileprivate func display(message:String)
   {
        print("hello",message)
    }
}


//private function display
private class fullTime : student
{
    var subject : String?
    
    override init() {
    self.subject = "fulltime Subject"
    }
    private func setSubject(subject : String)
    {
        self.subject = subject
    }
    
     //private func display()
    fileprivate func display()
    {
        //func display() {
        
        print("im method of fulltime class")
        super.display(message: "file private")
    }
}
