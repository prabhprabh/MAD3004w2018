//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var n:Int = 1
var i:Int = 5
var j:Int = i+1
if i < 10
{
    for i in 1...10
    {
        print(i*5)
    }
    
}
else
{for i in 1...5
{
    n = n * i
    }
    print("factorial :" ,n)
}
