//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var person = [String: Any]()
let address = [String : String]()


person["firstName"] = "prabh"
person["lastName"] = "chahal"
person["age"] = Int(22)
person["address"] = ["street" : "265 Yorkland Blvd", "area" : "North York", "postalCode" : "M1H1Y1"]
person["total amount"] = Double(2000)
print("person: ",person)
