//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



var name :String = "prabh"
var count_name: Int = name.count

print("The name in non-reverse format :")
var i :Character
var limit = Int(name.count)
var j :Int = 0

j = 0
if( j <= limit) {
    i = name[name.index(name.startIndex,offsetBy: 0)]
    print("\n",i)
    i = name[name.index(name.startIndex,offsetBy: 1)]
    print("\n",i)
    i = name[name.index(name.startIndex,offsetBy: 2)]
    print("\n",i)
    i = name[name.index(name.startIndex,offsetBy: 3)]
    print("\n",i)
    i = name[name.index(name.startIndex,offsetBy: 4)]
    print("\n",i)
    j = j+1
    
}

print("The name in reverse format :")


j = limit-1
while( j >= 0) {
    i = name[name.index(name.startIndex,offsetBy: j)]
    print("\n",i)
    j = j-1
    
}
