//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//classes
class Employee {
    var empId: Int?
    var empName: String?
    var basicPay: Double?
 
    
    //initializer in swift
    init() {
        self.empId=0
        self.empName="chahal"
        self.basicPay=2000
    }
    
    //parameterized initilizer
    init(Id: Int, Name: String, pay: Double){
        self.empId = Id
        self.empName = Name
        self.basicPay=pay
    }
    func display(){
        print("Employee ID : ", self.empId!)
        print("Employee Name : ", self.empName!)
        print("basic Pay : ", self.basicPay!)
        
    }
    
    //deinitializer
    deinit{
        print("Employee object deinitialized")
    }
}


var emp1 = Employee()
emp1.empId = 101
emp1.empName = "Prabh"
emp1.basicPay = 5000
//emp1.display()

var emp3 = Employee()
//emp3.display()

var emp4 = Employee(Id:104, Name:"prabhjot",pay:3088.89)
emp4.display()

//inheriting from employee class
class PermanentEmployee : Employee {
    var vacationWeeks : Int?
    
    //default initializer
    override init(){
        super.init()
        self.vacationWeeks = 0
        
    }
    
    //parametrized initilizer of sub clas
    init(Id: Int, Name: String, pay: Double, weeks: Int){
    super.init(Id: Id, Name: Name, pay: pay)
    self.vacationWeeks = weeks
        
    }
    
    override func display(){
        //super.display()
        print("VacationWeeks :",vacationWeeks!)
    }
}


var obj2 = PermanentEmployee()
//obj2.display()
obj2.empId = 102
obj2.empName = "prabh"
obj2.basicPay = 3000
obj2.vacationWeeks = 10
//obj2.display()


var obj5 = PermanentEmployee()
//obj5.display()


var obj6 = PermanentEmployee(Id: 111, Name: "prab", pay: 2001,  weeks: 3)
obj6.display()





class payroll : PermanentEmployee {
    var netPay : Double?
       /* get
        {
            let vw = self.vacationWeeks!
            if vw > 5
            {
                return self.basicPay! - 100
            }
            else
            {
                return self.basicPay
            }
        }
 
    }
    */
    
override init()
    {
        super.init()
        self.netPay = 0
        
    }
    
override init(Id: Int, Name: String, pay: Double, weeks: Int)
    {
        super.init(Id: Id, Name: Name, pay: pay,  weeks: weeks)
        self.netPay = 0
    }
    

    override func display() {
        super.display()
        self.calculate()
        print("netPay :", self.netPay!)
        
        }
        
        func calculate() {
            var vw = self.vacationWeeks!
            if vw > 5 {
                self.netPay! = self.basicPay! - 100
            }
            else{
                self.netPay! = self.basicPay!
            }
        }
 
    }


var obj7 = payroll(Id: 111, Name: "prab", pay: 2001,  weeks: 3)
obj7.display()


 //manipulate object array
 var janpayroll = [payroll]()
 let noOfEmployees = 2
 
 for i in 0..<2{
 janpayroll.append(payroll(Id: 102, Name: "prabbb", pay: 3333.33, weeks: 3))
 janpayroll[i].display()
 }
 

