//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var number : Int = 5
var factorial : Int = 1
var n :Int = number + 1
for i in 1..<n {
    factorial = factorial * i
}
print ("factorial of number is :",factorial)


let strOne = """
This is first line
This is another line
This is one more line
Ok. enough of lines
"""
print(strOne)

//use of unique code
var mood = ""
let heart = "\u{1f496}"
mood = "happy"
if mood.isEmpty {
    print("cheer up")
}
else{
    print(heart)
}



var firstname = String()
firstname = "prabh"
print(firstname)

for i in firstname {
    print(i)
}
let initial : Character = "p"
firstname.append(initial)
print(firstname)
print("firstname is \(firstname) which is \(firstname.count) characters long ")

var str1:String = "land"
str1 += "cruiser"
print(str1)
var Firstname:String = "prabhjot"
print(firstname)

print("start index:",firstname[ firstname.startIndex]) //print first character
print("before end index:",firstname[firstname.index(before:firstname.endIndex)])  //print last caharcter
print("after start index",firstname[firstname.index(after:firstname.startIndex)]) //print 2nd character
print("4th character:",firstname[firstname.index(firstname.startIndex,offsetBy: 2)])
print("5th character:",firstname[firstname.index(firstname.startIndex,offsetBy: 4)]) //print 5th character
print("3rd from character:",firstname[firstname.index(firstname.endIndex,offsetBy: -3)]) //print 3rd character



//add string into string
var language = "swift"
print("language :",language)

language.insert("!",at: language.endIndex)
print ("laguage :",language)

language.insert(contentsOf:"java", at: language.endIndex)
print("language :",language)

language.insert(contentsOf:" is nice than ",at: language.index(language.startIndex,offsetBy: 6))
print("language contentsOf:",language)

language.remove(at: language.index(before: language.endIndex))
print("language remove :",language)

let greeting = "Happy Holidays"
let index = greeting.index(of: " ") ?? greeting.endIndex
let start =  greeting[..<index]
let newGreet = String(start)

print("sub string :",newGreet)
print("string is uppercased :", newGreet.uppercased())

if (newGreet == newGreet.uppercased())
{
    print("equal")
}
else{
    print("not equal")
}
var grade : String?
//grade = "a"
let Finalgrade = grade ?? "F"
if (Finalgrade.isEmpty){
    print("not graded yet")
}

else{
    print("grade :", Finalgrade)

}




